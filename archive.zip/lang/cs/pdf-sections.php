<?php

return [
    "profile" => "Osobní informace",

    "summary" => "Souhrn",
    "summary_desc" => "Můžete napsat 2-3 krátké věty, které shrnují váš životopis a upoutají zájem čtenáře! Vaše nejdůležitější úspěchy a nejlepší kvalita nebo dovednost.",

    "experiences" => "ZKUŠENOSTI",
    "experiences_desc" => "Přidejte zaměstnání nebo pozice, které jste zastávali. V popisu hovořte o svých nejlepších úspěších a úkolech, které jste vykonávali.",

    "education" => "Vzdělání",
    "education_desc" => "Přidejte své vzdělávací kvalifikace, jako je vysokoškolský titul, magisterský titul nebo doktorát. Neuvádějte maturitu, pokud jste nedokončili vysokoškolská studia.",

    "languages" => "Jazyky",
    "languages_desc" => "V této sekci přidejte jazyky, kterými hovoříte plynně.",

    "skills" => "Dovednosti",
    "skills_desc" => "Přidejte své dovednosti, které vám mohou pomoci získat práci.",

    "interests" => "Zájmy",

    "courses" => "Kurzy",

    "optional_section" => "Tato sekce je nepovinná",

    "contact_info" => "Kontaktní informace",

    "custom" => "Vlastní sekce"
];
