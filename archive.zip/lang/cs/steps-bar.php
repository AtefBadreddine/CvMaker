<?php

return [
    "one" => "Jazyk životopisu",
    "two" => "Změňte design",
    "two_dev" => "Vyberte šablonu svého životopisu",
    "three" => "Obecné",
    "four" => "Vzdělání",
    "five" => "Pracovní zkušenosti",
    "six" => "Další",
    "seven" => "Náhled",
];
