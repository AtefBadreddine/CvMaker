<?php

return [
    "profile" => "Personlige oplysninger",

    "summary" => "Resumé",
    "summary_desc" => "Du kan skrive 2-3 korte sætninger for at opsummere dit CV og vække læserens interesse! Dine vigtigste præstationer og bedste kvalitet eller færdighed.",

    "experiences" => "ERFARINGER",
    "experiences_desc" => "Tilføj de job eller stillinger, du har haft. I beskrivelsen, tal om dine bedste præstationer og de opgaver, du udførte.",

    "education" => "Uddannelse",
    "education_desc" => "Tilføj din uddannelseskvalifikation, såsom en universitetsgrad, kandidatgrad eller doktorgrad. Tilføj ikke et gymnasieeksamen medmindre du ikke har afsluttet dine universitetsstudier.",

    "languages" => "Sprog",
    "languages_desc" => "I denne sektion tilføjer du de sprog, du taler flydende.",

    "skills" => "Færdigheder",
    "skills_desc" => "Tilføj dine færdigheder, der kan hjælpe dig med at få et job.",

    "interests" => "Interesser",

    "courses" => "Kurser",

    "optional_section" => "Denne sektion er valgfri",

    "contact_info" => "Kontaktinformation",

    "custom" => "Tilpasset sektion"
];
