<?php

return [
    "one" => "CV sprog",
    "two" => "Skift designet",
    "two_dev" => "Vælg din CV-skabelon",
    "three" => "Generelt",
    "four" => "Uddannelse",
    "five" => "Joberfaring",
    "six" => "Andet",
    "seven" => "Forhåndsvisning",
];
