<?php

return [
    "one" => "Lebenslauf Sprache",
    "two" => "Ändern Sie das Design",
    "two_dev" => "Wählen Sie Ihre Lebenslaufvorlage",
    "three" => "Persönliche Infos",
    "four" => "Ausbildung",
    "five" => "Berufserfahrung",
    "six" => "Andere",
    "seven" => "Vorschau",
];