<?php

return [
    "one" => "CV language",
    "two" => "Change the template",
    "two_dev" => "Choose your CV template",
    "three" => "General",
    "four" => "Education",
    "five" => "Job Experince",
    "six" => "Other",
    "seven" => "Preview",
];