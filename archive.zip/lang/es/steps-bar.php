<?php

return [
    "one" => "Idioma del CV",
    "two" => "Cambiar el diseño",
    "two_dev" => "Elige tu plantilla de CV",
    "three" => "General",
    "four" => "Educación",
    "five" => "Experiencia Laboral",
    "six" => "Otros",
    "seven" => "Vista Previa",
];
?>

