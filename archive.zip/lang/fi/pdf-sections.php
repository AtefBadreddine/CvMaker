<?php

return [
    "profile" => "Henkilötiedot",

    "summary" => "Yhteenveto",
    "summary_desc" => "Voit kirjoittaa 2-3 lyhyttä lausetta tiivistääksesi ansioluettelosi ja herättääksesi lukijan kiinnostuksen! Tärkeimmät saavutuksesi ja paras laatusi tai taitosi.",

    "experiences" => "KOKEMUKSET",
    "experiences_desc" => "Lisää työt tai tehtävät, joita olet pitänyt. Kuvaile parhaita saavutuksiasi ja suorittamiasi tehtäviä.",

    "education" => "Koulutus",
    "education_desc" => "Lisää koulutukselliset pätevyytesi, kuten yliopistotutkinto, maisterin tutkinto tai tohtorin tutkinto. Älä lisää lukiopohjaista tutkintoa, ellet ole suorittanut yliopisto-opintojasi.",

    "languages" => "Kielet",
    "languages_desc" => "Tässä osiossa lisää kielet, joita puhut sujuvasti.",

    "skills" => "Taidot",
    "skills_desc" => "Lisää taidot, jotka voivat auttaa sinua saamaan työpaikan.",

    "interests" => "Kiinnostuksen kohteet",

    "courses" => "Kurssit",

    "optional_section" => "Tämä osio on valinnainen",

    "contact_info" => "Yhteystiedot",

    "custom" => "Mukautettu osio"
];
