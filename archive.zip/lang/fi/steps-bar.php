<?php

return [
    "one" => "CV:n kieli",
    "two" => "Muuta mallia",
    "two_dev" => "Valitse CV-mallisi",
    "three" => "Yleinen",
    "four" => "Koulutus",
    "five" => "Työkokemus",
    "six" => "Muut",
    "seven" => "Esikatselu",
];
