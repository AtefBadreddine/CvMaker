<?php

return [
    "one" => "Langue",
    "two" => "Changer le design",
    "two_dev" => "Choisissez un modèle de CV",
    "three" => "Coordonnées",
    "four" => "Formation",
    "five" => "Expérience",
    "six" => "Autres sections",
    "seven" => "Aperçu",
];