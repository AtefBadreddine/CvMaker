<?php

return [
    "one" => "CV nyelve",
    "two" => "Változtassa meg a dizájnt",
    "two_dev" => "Válaszd ki az önéletrajzod sablonját",
    "three" => "Általános",
    "four" => "Oktatás",
    "five" => "Munkatapasztalat",
    "six" => "Egyéb",
    "seven" => "Előnézet",
];
