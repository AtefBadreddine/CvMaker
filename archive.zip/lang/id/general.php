<?php

return [
    "title" => "Pembuat CV Gratis",
    "home_title" => "Pilih bahasa CV Anda",
    "footer" => "Hak cipta dilindungi",
    "subTitle" => "Anda dapat mengubah templat nanti",
    "addPic" => "Tambahkan Gambar",
    "fontSize" => "Ukuran Font",
    "cvColor" => "Pilih Warna",
    "printBtn" => "Cetak",
    "downloadBtn" => "Unduh (PDF)",
    "addMoreBtn" => "Tambahkan item baru",
    "addMoreEduBtn" => "Tambahkan pendidikan",
    "addMoreJobBtn" => "Tambahkan Pekerjaan",
    "addMoreSkillBtn" => "Tambahkan Keahlian",
    "addMoreLangBtn" => "Tambahkan Bahasa",
    "addMoreInterestBtn" => "Tambahkan Minat",
    "new_page_titel" => "Paksa pemisahan halaman bagian",
    "new_page_desc" => "Pindahkan bagian ini ke halaman berikutnya (PDF) dengan memaksa pemisahan halaman. Misalnya, untuk mencegah bagian tersebut terbagi pada pemisahan halaman reguler.",
    "addNewSectionTitle" => "Tambahkan Bagian",
    "contact_us" => "Hubungi Kami",
    "policy" => "Kebijakan Privasi",
    "about_us" => "Tentang Kami"
];
?>