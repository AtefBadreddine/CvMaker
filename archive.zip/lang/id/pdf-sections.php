<?php

return [
    "profile" => "Informasi Pribadi",

    "summary" => "Ringkasan",
    "summary_desc" => "Anda dapat menulis 2-3 kalimat singkat untuk merangkum resume Anda dan menarik perhatian pembaca! Prestasi terpenting Anda dan kualitas atau keterampilan terbaik.",

    "experiences" => "PENGALAMAN",
    "experiences_desc" => "Tambahkan pekerjaan atau posisi yang pernah Anda pegang. Dalam deskripsi, bicarakan tentang pencapaian terbaik Anda dan tugas-tugas yang Anda lakukan.",

    "education" => "Pendidikan",
    "education_desc" => "Tambahkan kualifikasi pendidikan Anda, seperti gelar universitas, master, atau doktor. Jangan tambahkan ijazah SMA kecuali Anda belum menyelesaikan studi universitas Anda.",

    "languages" => "Bahasa",
    "languages_desc" => "Di bagian ini, tambahkan bahasa yang Anda kuasai.",

    "skills" => "Keterampilan",
    "skills_desc" => "Tambahkan keterampilan Anda yang dapat membantu Anda mendapatkan pekerjaan.",

    "interests" => "Minat",

    "courses" => "Kursus",

    "optional_section" => "Bagian ini opsional",

    "contact_info" => "Info Kontak",

    "custom" => "Bagian Kustom"
];
