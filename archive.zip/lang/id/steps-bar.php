<?php

return [
    "one" => "Bahasa CV",
    "two" => "Ubah desainnya",
    "two_dev" => "Pilih template CV Anda",
    "three" => "Umum",
    "four" => "Pendidikan",
    "five" => "Pengalaman Kerja",
    "six" => "Lainnya",
    "seven" => "Pratinjau",
];
