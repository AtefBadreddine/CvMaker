<?php

return [
    "one" => "Lingua del CV",
    "two" => "cambiare il disegno",
    "two_dev" => "Scegli il tuo template per il CV",
    "three" => "Generale",
    "four" => "Istruzione e Formazione",
    "five" => "Esperienze Lavorative",
    "six" => "Altro",
    "seven" => "Anteprima",
];
