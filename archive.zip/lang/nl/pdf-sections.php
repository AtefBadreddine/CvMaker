<?php

return [
    "profile" => "Persoonlijke Informatie",

    "summary" => "Samenvatting",
    "summary_desc" => "Je kunt 2-3 korte zinnen schrijven om je cv samen te vatten en de interesse van de lezer te wekken! Je belangrijkste prestaties en beste kwaliteit of vaardigheid.",

    "experiences" => "ERVARINGEN",
    "experiences_desc" => "Voeg de banen of posities toe die je hebt gehouden. Bespreek in de beschrijving je beste prestaties en de taken die je uitvoerde.",

    "education" => "Opleiding",
    "education_desc" => "Voeg je onderwijskwalificaties toe, zoals een universitair diploma, masterdiploma of doctoraat. Voeg geen middelbare schooldiploma toe, tenzij je je universitaire studies niet hebt afgerond.",

    "languages" => "Talen",
    "languages_desc" => "Voeg in deze sectie de talen toe waarin je vloeiend bent.",

    "skills" => "Vaardigheden",
    "skills_desc" => "Voeg je vaardigheden toe die je kunnen helpen een baan te krijgen.",

    "interests" => "Interesses",

    "courses" => "Cursussen",

    "optional_section" => "Deze sectie is optioneel",

    "contact_info" => "Contactinformatie",

    "custom" => "Aangepaste Sectie"
];
