<?php

return [
    "one" => "Taal",
    "two" => "Sjabloon",
    "two_dev" => "Kies je CV-sjabloon",
    "three" => "Algemeen",
    "four" => "Opleiding",
    "five" => "Werkervaring",
    "six" => "Overig",
    "seven" => "Voorbeeld",
];
