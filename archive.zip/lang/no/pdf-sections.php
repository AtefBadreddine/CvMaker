<?php

return [
    "profile" => "Personlig informasjon",

    "summary" => "Sammendrag",
    "summary_desc" => "Du kan skrive 2-3 korte setninger for å oppsummere CV-en din og vekke leserens interesse! Dine viktigste prestasjoner og beste kvaliteter eller ferdigheter.",

    "experiences" => "ERFARINGER",
    "experiences_desc" => "Legg til jobber eller stillinger du har hatt. I beskrivelsen, snakk om dine beste prestasjoner og oppgavene du utførte.",

    "education" => "Utdanning",
    "education_desc" => "Legg til din utdanningskvalifikasjon, som en universitetsgrad, mastergrad eller doktorgrad. Ikke legg til en videregående skolediplom med mindre du ikke har fullført universitetsstudiene dine.",

    "languages" => "Språk",
    "languages_desc" => "I denne delen kan du legge til de språkene du behersker.",

    "skills" => "Ferdigheter",
    "skills_desc" => "Legg til ferdighetene dine som kan hjelpe deg med å få en jobb.",

    "interests" => "Interesser",

    "courses" => "Kurs",

    "optional_section" => "Denne seksjonen er valgfri",

    "contact_info" => "Kontaktinformasjon",

    "custom" => "Egendefinert Seksjon"
];
