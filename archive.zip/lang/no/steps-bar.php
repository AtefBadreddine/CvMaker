<?php

return [
    "one" => "CV-språk",
    "two" => "Endre designet",
    "two_dev" => "Velg din CV-mal",
    "three" => "Generelt",
    "four" => "Utdanning",
    "five" => "Jobberfaring",
    "six" => "Annet",
    "seven" => "Forhåndsvisning",
];