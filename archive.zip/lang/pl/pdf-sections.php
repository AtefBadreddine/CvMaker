<?php

return [
    "profile" => "Dane osobowe",

    "summary" => "Podsumowanie",
    "summary_desc" => "Możesz napisać 2-3 krótkie zdania, aby podsumować swoje CV i zainteresować czytelnika! Twoje najważniejsze osiągnięcia i najlepsze umiejętności.",

    "experiences" => "DOŚWIADCZENIE",
    "experiences_desc" => "Dodaj stanowiska, które zajmowałeś. W opisie opisz swoje najlepsze osiągnięcia i wykonywane zadania.",

    "education" => "Edukacja",
    "education_desc" => "Dodaj swoje kwalifikacje edukacyjne, takie jak stopień licencjata, magistra lub doktoratu. Nie dodawaj świadectwa ukończenia szkoły średniej, chyba że nie ukończyłeś studiów wyższych.",

    "languages" => "Języki",
    "languages_desc" => "W tej sekcji dodaj języki, w których jesteś biegły.",

    "skills" => "Umiejętności",
    "skills_desc" => "Dodaj umiejętności, które mogą pomóc Ci znaleźć pracę.",

    "interests" => "Zainteresowania",

    "courses" => "Kursy",

    "optional_section" => "Ta sekcja jest opcjonalna",

    "contact_info" => "Informacje kontaktowe",

    "custom" => "Sekcja niestandardowa"
];
