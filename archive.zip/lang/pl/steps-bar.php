<?php

return [
    "one" => "Język",
    "two" => "Szablon",
    "two_dev" => "Wybierz szablon CV",
    "three" => "Ogólne",
    "four" => "Edukacja",
    "five" => "Doświadczenie zawodowe",
    "six" => "Inne",
    "seven" => "Podgląd",
];
