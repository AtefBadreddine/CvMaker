<?php

return [
    "one" => "Idioma do CV",
    "two" => "mudar o desenho",
    "two_dev" => "Escolha um modelo para criar seu novo currículo",
    "three" => "detalhes pessoais",
    "four" => "Formação",
    "five" => "Experiência profissional",
    "six" => "Other",
    "seven" => "Visualizar",
];