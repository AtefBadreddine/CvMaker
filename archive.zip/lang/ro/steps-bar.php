<?php

return [
    "one" => "Limba CV-ului",
    "two" => "Schimbați designul",
    "two_dev" => "Alegeți șablonul CV-ului dvs.",
    "three" => "General",
    "four" => "Educație",
    "five" => "Experiență în muncă",
    "six" => "Altele",
    "seven" => "Previzualizare",
];
