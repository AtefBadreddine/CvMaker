<?php

return [
    "title" => "Gratis CV-skapare",
    "home_title" => "Välj ditt CV:s språk",
    "footer" => "Alla rättigheter förbehållna",
    "subTitle" => "Du kan ändra mallen senare",
    "addPic" => "Lägg till Bild",
    "fontSize" => "Typstorlek",
    "cvColor" => "Välj Färg",
    "printBtn" => "Skriv ut",
    "downloadBtn" => "Ladda ner (PDF)",
    "addMoreBtn" => "Lägg till nytt objekt",
    "addMoreEduBtn" => "Lägg till utbildning",
    "addMoreJobBtn" => "Lägg till Jobb",
    "addMoreSkillBtn" => "Lägg till Färdighet",
    "addMoreLangBtn" => "Lägg till Språk",
    "addMoreInterestBtn" => "Lägg till Intresse",
    "new_page_titel" => "Tvinga sidbrytning i avsnitt",
    "new_page_desc" => "Flytta denna sektion till nästa sida (PDF) genom att tvinga fram en sidbrytning. Till exempel för att förhindra att sektionen bryts vid en vanlig sidbrytning.",
    "addNewSectionTitle" => "Lägg till Sektion",
    "contact_us" => "Kontakta Oss",
    "policy" => "Integritetspolicy",
    "about_us" => "Om Oss"
];
?>