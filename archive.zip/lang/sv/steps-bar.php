<?php

return [
    "one" => "CV språk",
    "two" => "Ändra designen",
    "two_dev" => "Välj din CV-mall",
    "three" => "Allmänt",
    "four" => "Utbildning",
    "five" => "Arbetslivserfarenhet",
    "six" => "Övrigt",
    "seven" => "Förhandsvisning",
];
