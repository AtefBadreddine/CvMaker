<?php

return [
    "profile" => "Kişisel Bilgiler",

    "summary" => "Özet",
    "summary_desc" => "Özgeçmişinizi özetlemek ve okuyucunun ilgisini çekmek için 2-3 kısa cümle yazabilirsiniz! En önemli başarılarınız ve en iyi kaliteniz veya beceriniz.",

    "experiences" => "DENEYİMLER",
    "experiences_desc" => "Üstlendiğiniz işleri veya pozisyonları ekleyin. Açıklamada, en iyi başarılarınızdan ve gerçekleştirdiğiniz görevlerden bahsedin.",

    "education" => "Eğitim",
    "education_desc" => "Üniversite diploması, yüksek lisans veya doktora gibi eğitim yeterliliklerinizi ekleyin. Üniversite eğitiminizi tamamlamadıysanız dışında, lise diploması eklemeyin.",

    "languages" => "Diller",
    "languages_desc" => "Bu bölümde, akıcı olduğunuz dilleri ekleyin.",

    "skills" => "Beceriler",
    "skills_desc" => "İş bulmanıza yardımcı olabilecek becerilerinizi ekleyin.",

    "interests" => "İlgi Alanları",

    "courses" => "Kurslar",

    "optional_section" => "Bu bölüm isteğe bağlıdır",

    "contact_info" => "İletişim Bilgileri",

    "custom" => "Özel Bölüm"
];
?>
