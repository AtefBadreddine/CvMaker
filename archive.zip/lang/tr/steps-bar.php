<?php

return [
    "one" => "CV dili",
    "two" => "Tasarımı değiştir",
    "two_dev" => "CV şablonunuzu seçin",
    "three" => "Genel",
    "four" => "Eğitim",
    "five" => "İş Deneyimi",
    "six" => "Diğer",
    "seven" => "Önizleme",
];
?>
