@php
    $currentLocale = session()->get('selectedLang') ?? ($cv->selectedLang ?? 'en');
    $jobsBreaked = false;
@endphp
<!DOCTYPE html>
<html lang="{{$currentLocale}}" dir="{{$currentLocale == 'ar' ? 'rtl' : 'ltr'}}">

<head>
    <title>{!!$cv->name ?? "" . "'s cv"!!}</title>

    <!-- Meta -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        *
        {
            font-family:'Cairo';
        }
        body
        {
            margin: 0;
            padding: 0;
            background-color: {{$cv->cv_color ?? '#2a5fb0'}};
            color: #545E6C;
        }

        table {
            border-spacing: 1;
            border-collapse: collapse;
            overflow: wrap;
            width: 100%;
            margin: 0 auto;
            position: relative;
            padding-top: 15px;
        }

        table * {
            position: relative;
        }


        td,th {
            padding: 20px;
        }

        table td,
        table th {
          font-size: {{$cv->cv_text_size ?? '14'}}px;
            @if($currentLocale == 'ar')
            text-align: right;
            font-family:'Cairo';
            @else
            text-align: left;
            font-family:'Roboto';
            @endif
        }

        .name
        {
            font-size: {{$cv->cv_text_size+16 ?? '30'}}px
        }

        table th .title,
        table td .title
        {
            font-size: {{$cv->cv_text_size + 4 ?? '18'}}px;
        }

        .gray-text
        {
            color: #97AAC3;
        }

        table th.section-title {
            color: {{$cv->cv_color ?? '#2a5fb0'}};
            padding-bottom: 0;
            padding-top: 20px;
            font-size: {{$cv->cv_text_size+6 ?? '20'}}px;
            font-weight: 500;
        }

        .sidebar table td,
        .sidebar table th
        {
            color:white;
            padding:10px;
            @if($currentLocale == 'ar')
            padding-right: 15px;
            padding-left: 0px;
            @else
            padding-left: 15px;
            padding-right: 0px;
            @endif
        }

        table td.info-section
        {
            text-align: center;
            padding: 20px !important;
            background-color: {{$cv->cv_color ?? '#2a5fb0'}};
            width: 100%
        }

        .sidebar table th.sidebar-title
        {
            background-color: {{$cv->darker_color ?? '#224c8d'}};
            font-size: {{$cv->cv_text_size+2 ?? '16'}}px;
        }

        table td .details,
        table th .details
        {
            font-size: {{$cv->cv_text_size ?? '14'}}px !important;
            font-weight:300;
            color: #545E6C;
            padding-top: 10px
        }
    </style>
</head>

<body>
    <div 
        class="sidebar" 
        @if($currentLocale == 'ar')
        style="position: relative;float:right;width: 28%;background:{{$cv->cv_color ?? '#2a5fb0'}};color:white;"
        @else
        style="position: relative;float:left;width: 28%;background:{{$cv->cv_color ?? '#2a5fb0'}};color:white;"
        @endif
        >
        <table>
            <tbody>
                <tr>
                    <td class="info-section">
                        @if (gettype($cv->picture) === 'string')
                            <img src="{{ asset('storage/cv/pictures') . '/' . $cv->picture }}" />
                            <br><br>
                        @endif
                        <span class="name">{{$cv->name ?? ""}}</span>
                        <br><br>
                        {{$cv->current_job ?? ""}}
                    </td>
                </tr>
                @if ($cv->email)
                    <tr>
                        <td>{{ $cv->email }}</td>
                    </tr>
                @endif
                @if ($cv->phone)
                    <tr>
                        <td>{{ $cv->phone }}</td>
                    </tr>
                @endif
                @if ($cv->address)
                    <tr>
                        <td>{{ $cv->address }}</td>
                    </tr>
                @endif
                @if ($cv->city)
                    <tr>
                        <td>{{ $cv->city }}</td>
                    </tr>
                @endif
                @if ($cv->birth_date)
                    <tr>
                        <td>{{ $cv->birth_date }}</td>
                    </tr>
                @endif
                @if ($cv->marital_status)
                    <tr>
                        <td>{{ $cv->marital_status }}</td>
                    </tr>
                @endif
                @if ($cv->nationality)
                    <tr>
                        <td>{{ $cv->nationality }}</td>
                    </tr>
                @endif
            </tbody>
        </table>
        @if ($cv->language || isset($cv->languages))
            <table >
                <thead>
                    <tr>
                        <th class="sidebar-title">{{ $cv->langs_section_title ?? __('pdf-sections.languages') }}</th>
                    </tr>
                </thead>
                <tbody>
                  @isset($cv->language)
                    <tr>
                        <td scope="col">
                            {{ $cv->language }} {{ $cv->level ?? '' }}
                        </td>
                    </tr>
                  @endisset
                    @isset($cv->languages)
                        @foreach ($cv->languages as $language)
                            <tr>
                                <td>
                                    {{ $language['language'] }} {{ $language['level'] ?? '' }}
                                </td>
                            </tr>
                        @endforeach
                    @endisset
                </tbody>
            </table>
        @endif

        @if ($cv->skill || isset($cv->skills))
            <table >
                <thead>
                    <tr>
                        <th class="sidebar-title">{{ $cv->skills_section_title ?? __('pdf-sections.skills') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @isset($cv->skill)
                    <tr>
                        <td>{{ $cv->skill }}</td>
                    </tr>
                  @endisset
                    @isset($cv->skills)
                        @foreach ($cv->skills as $skill)
                            <tr>
                                <td>{{ $skill['skill'] }}</td>
                            </tr>
                        @endforeach
                    @endisset
                </tbody>
            </table>
        @endif

        @isset($cv->interests)
            <table>
                <thead>
                    <tr>
                        <th class="sidebar-title">{{ $cv->interests_section_title ?? __('pdf-sections.interests') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($cv->interests as $interest)
                        <tr>
                            <td>{{ $interest['interest'] }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>  
        @endisset
    </div>

    <div 
        class="page" 
        @if($currentLocale == 'ar')
        style="position: relative; float:left; width:71.5%; background:#fff;height:100%;page-break-inside: avoid;"
        @else
        style="position: relative; float:right; width:71.5%; background:#fff;height:100%;page-break-inside: avoid;"
        @endif
        >
        @if($cv->profession_summary)
            <table >
                <thead>
                    <tr>
                        <th class="section-title">{{$cv->summary_section_title ?? __('pdf-sections.summary')}}</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><div class="details" style="text-align: justify !important">{!!str_replace("\n","<br/>",$cv->profession_summary)!!}</div></td>
                    </tr>
                </tbody>
            </table>
        @endif

        @if($cv->jobs)
            <table >
                <thead>
                    <tr>
                        <th scope="col" colspan="2" class="section-title">{{$cv->jobs_section_title ?? __('pdf-sections.experiences')}}</th>
                    </tr>
                </thead>
                <tbody>

                    @isset($cv->jobs)
                        @foreach ($cv->jobs as  $job)
                            <tr>
                                <td style="width: 20%" class="gray-text" style="vertical-align: top">{{$job['jobStartYear'] ?? ""}}{{$job['jobEndYear'] ? ' - ' . $job['jobEndYear'] : ""}}</td>
                                <td scope="col" style="width: 75%">
                                    <span class="title">{{$job['job_title'] ?? ""}}</span>
                                    <br>
                                    <br>
                                    <span class="gray-text">{{$job['employer']  ?? ""}}{{$job['job_city'] ? ', '. $job['job_city'] : ""}}</span>
                                    <p class="details">{!!str_replace("\n","<br/>",$job['details'] ?? "")!!}</p>
                                </td>
                            </tr>
                        @endforeach
                    @endisset
                </tbody>
            </table>
        @endif

        @if($cv->educations)
            <table >
                <thead>
                    <tr>
                        <th scope="col" colspan="2" class="section-title">{{$cv->education_section_title ?? __('pdf-sections.education')}}</th>
                    </tr>
                </thead>
                <tbody>

                    @isset($cv->educations)
                        @foreach ($cv->educations as  $education)
                            <tr>
                                <td style="width: 20%" class="gray-text" style="vertical-align: top">{{$education['startYear'] ?? ""}} <br/> {{$education['endYear'] ? ' - ' . $education['endYear'] : ""}}</td>
                                <td scope="col" style="width:75%">
                                    <strong class="title">{{$education['degree'] ?? ""}}</strong>
                                    <br>
                                    <br>
                                    {{$education['university'] ?? ""}} {{$education['education_city'] ? ', '.$education['education_city'] : ""}}
                                  	<p class="details" style="padding-top:5px">{!!str_replace("\n","<br/>",$education['details'] ?? "")!!}</p>
                                </td>
                            </tr>
                        @endforeach
                    @endisset
                </tbody>
            </table>
        @endif

        @isset($cv->customSections)
            @foreach ($cv->customSections as $section)
            <table >
                <thead>
                    <tr>
                        <th scope="col" class="section-title">{{$section['customSectionTitle'] ?? ""}}</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <p>{!!str_replace("\n","<br/>",$section['customSectionDetails'] ?? "")!!}</p>
                        </td>
                    </tr>
                </tbody>
            </table>
            @endforeach
        @endisset
    </div>
    @if($currentLocale == 'ar')
    <div class="page" style="position: relative; float:left; width:71.5%; background:#fff;height:100%;"></div>
    @else
    <div class="page" style="position: relative; float:right; width:71.5%; background:#fff;height:100%;"></div>
    @endif
</body>

</html>
