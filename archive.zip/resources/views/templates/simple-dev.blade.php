@php
    $currentLocale = session()->get('selectedLang') ?? ($cv->selectedLang ?? 'en');
@endphp
<!DOCTYPE html>
<html lang="{{$currentLocale}}" dir="{{$currentLocale == 'ar' ? 'rtl' : 'ltr'}}">

<head>
    <title>{!!$cv->name ?? "" . "'s cv"!!}</title>

    <!-- Meta -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
      html,body{
height:100%;
 min-height:100%; 
}
        *
        {
            font-family:'Cairo';
        }
        body
        {
            margin: 0;
            padding: 0;
            background-color: {{$cv->lighter_color ?? '#ecf3fb'}};
            color: #545E6C;
        }

        table {
            border-spacing: 1;
            border-collapse: collapse;
            overflow: wrap;
            width: 100%;
            margin: 0 auto;
            position: relative;
            padding-top: 15px;
        }

        table * {
            position: relative;
        }


        td,th {
            padding: 20px;
        }

        table td,
        table th {
            font-size: {{$cv->cv_text_size ?? '14'}}px;
            @if($currentLocale == 'ar')
            text-align: right;
            font-family:'Cairo';
            @else
            text-align: left;
            font-family:'Roboto';
            @endif
        }

        .name
        {
            font-size: {{$cv->cv_text_size+16 ?? '30'}}px;
        }

        

        .name,
        .tagline
        {
            padding: 0;
            margin: 0;
            font-weight: 300;
            line-height: 1.6;
        }
        .tagline
        {
            font-size: {{$cv->cv_text_size+4 ?? '18'}}px;
        }

        table th .title,
        table td .title
        {
            font-size: {{$cv->cv_text_size+4 ?? '18'}}px;
        }

        .gray-text
        {
            color: #97AAC3;
        }

        table th.section-title {
          	color:{{$cv->cv_color ?? '#004b8a'}};
            padding-bottom: 0;
            padding-top: 20px;
            font-size: {{$cv->cv_text_size+6 ?? '20'}}px;
            font-weight: 900;
            padding-bottom: 10px;
        }

        .sidebar table td,
        .sidebar table th
        {
            color:#222;
            padding:10px;
            @if($currentLocale == 'ar')
            padding-right: 20px;
            padding-left: 0px;
            @else
            padding-left: 20px;
            padding-right: 0px;
            @endif
        }

        table td.info-section
        {
            text-align: center;
            padding: 20px !important;
            width: 100%
        }

        .sidebar table th.sidebar-title
        {
            font-size: {{$cv->cv_text_size+4 ?? '18'}}px;
            color: {{$cv->cv_color ?? '#004b8a'}};
          	padding-top:20px
        }

        table td .details,
        table th .details
        {
            font-size: {{$cv->cv_text_size ?? '14'}}px; !important;
            font-weight:300;
            color: #545E6C;
            padding-top: 10px
        }
    </style>
</head>

<body>
    <div 
        class="sidebar" 
        @if($currentLocale == 'ar')
        style="position: relative;float:left;width: 33%;background:{{$cv->lighter_color ?? '#ecf3fb'}};color:#222;"
        @else
        style="position: relative;float:right;width: 33%;background:{{$cv->lighter_color ?? '#ecf3fb'}};color:#222;"
        @endif
        >
        <table>
            <tbody>
                <tr>
                    <td class="info-section">
                        @if (gettype($cv->picture) === 'string')
                            <img src="{{ asset('storage/cv/pictures') . '/' . $cv->picture }}" />
                            <br><br>
                        @endif
                    </td>
                </tr>
                <tr>
                    <th class="sidebar-title" style="padding-top:20px;padding-bottom:20px;">{{ __('pdf-sections.profile') }}</th>
                </tr>
                @if ($cv->email)
                    <tr>
                      <td><strong>{{ __('labels.email') }}:<br/></strong>{{ $cv->email }}</td>
                    </tr>
                @endif
                @if ($cv->phone)
                    <tr>
                        <td><strong>{{ __('labels.phone') }}:<br/></strong>{{ $cv->phone }}</td>
                    </tr>
                @endif
                @if ($cv->address)
                    <tr>
                        <td><strong>{{ __('labels.address') }}:<br/></strong>{{ $cv->address }}</td>
                    </tr>
                @endif
                @if ($cv->city)
                    <tr>
                        <td><strong>{{ __('labels.city') }}:<br/></strong>{{ $cv->city }}</td>
                    </tr>
                @endif
                @if ($cv->birth_date)
                    <tr>
                        <td><strong>{{ __('labels.birth_date') }}:<br/></strong>{{ $cv->birth_date }}</td>
                    </tr>
                @endif
                @if ($cv->marital_status)
                    <tr>
                        <td><strong>{{ __('labels.marital_status') }}:<br/></strong>{{ $cv->marital_status }}</td>
                    </tr>
                @endif
                @if ($cv->nationality)
                    <tr>
                        <td><strong>{{ __('labels.nationality') }}:<br/></strong>{{ $cv->nationality }}</td>
                    </tr>
                @endif
            </tbody>
        </table>
        @if ($cv->language || isset($cv->languages))
            <table >
                <thead>
                    <tr>
                        <th class="sidebar-title">{{ $cv->langs_section_title ?? __('pdf-sections.languages') }}</th>
                    </tr>
                </thead>
                <tbody>
                  @isset($cv->language)
                    <tr>
                        <td scope="col">
                           • {{ $cv->language }} {{ $cv->level ?? '' }}
                        </td>
                    </tr>
                  @endisset
                    @isset($cv->languages)
                        @foreach ($cv->languages as $language)
                            <tr>
                                <td>
                                    • {{ $language['language'] }} {{ $language['level'] ?? '' }}
                                </td>
                            </tr>
                        @endforeach
                    @endisset
                </tbody>
            </table>
        @endif

        @if ($cv->skill || isset($cv->skills))
            <table >
                <thead>
                    <tr>
                        <th class="sidebar-title">{{ $cv->skills_section_title ?? __('pdf-sections.skills') }}</th>
                    </tr>
                </thead>
                <tbody>
                  @isset($cv->skill)
                    <tr>
                        <td>• {{ $cv->skill }}</td>
                    </tr>
                  @endisset
                    @isset($cv->skills)
                        @foreach ($cv->skills as $skill)
                            <tr>
                                <td>• {{ $skill['skill'] }}</td>
                            </tr>
                        @endforeach
                    @endisset
                </tbody>
            </table>
        @endif

        @isset($cv->interests)
            <table>
                <thead>
                    <tr>
                        <th class="sidebar-title">{{ $cv->interests_section_title ?? __('pdf-sections.interests') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($cv->interests as $interest)
                        <tr>
                            <td>• {{ $interest['interest'] }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>  
        @endisset
    </div>

    <div 
        class="page" 
        @if($currentLocale == 'ar')
        style="position: relative; float:right; width:66%; background:#fff;height:100%;page-break-inside: avoid;"
        @else
        style="position: relative; float:left; width:66%; background:#fff;height:100%;page-break-inside: avoid;"
        @endif
        >
      	<table >
            <thead>
              <tr>
                <th class="section-title" style="font-size:40px;padding-bottom:0">{{$cv->name ?? ""}}</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style="padding-top:5px">{{$cv->current_job ?? ""}}</td>
              </tr>
            </tbody>
        </table>
        @if($cv->profession_summary)
            <table >
                <tbody>
                    <tr>
                        <td><div class="details" style="text-align: justify !important">{!!str_replace("\n","<br/>",$cv->profession_summary ?? "")!!}</div></td>
                    </tr>
                </tbody>
            </table>
        @endif

        @if($cv->jobs)
            <table >
                <thead>
                    <tr>
                        <th scope="col" class="section-title">{{$cv->jobs_section_title ?? __('pdf-sections.experiences')}}</th>
                    </tr>
                </thead>
                <tbody>
                    @isset($cv->jobs)
                        @foreach ($cv->jobs as  $job)
                            <tr>
                                <td scope="col" style="padding-bottom:0"><strong><span class="title">{{$job['job_title'] ?? ""}}</span> </strong> {{$job['employer'] ? '| '.$job['employer'] : ""}}</td>
                            </tr>
                  			<tr>
                              <td style="padding-bottom:0;padding-top:5px"><span>{{$job['jobStartYear'] ?? ""}}{{$job['jobEndYear'] ? ' - '.$job['jobEndYear'] : ""}}{{$job['job_city'] ? ' | '.$job['job_city'] : ""}}</span></td>
                  			</tr>
                  			<tr>
                              <td style="padding-top:5px"><p class="details">{!!str_replace("\n","<br/>",$job['details'] ?? "")!!}</p></td>
                  			</tr>
                        @endforeach
                    @endisset
                </tbody>
            </table>
        @endif

        @if($cv->educations)
            <table >
                <thead>
                    <tr>
                        <th scope="col" class="section-title">{{$cv->education_section_title ?? __('pdf-sections.education')}}</th>
                    </tr>
                </thead>
                <tbody>
                    @isset($cv->educations)
                        @foreach ($cv->educations as  $education){{$education['degree'] ?? ""}}
                  			<tr>
                              <td style="padding-bottom:0"><strong class="title">{{$education['university'] ?? ""}}{{$education['education_city'] ? ', '.$education['education_city'] : ""}}</strong>, </td>
                  			</tr>
                            <tr>
                                <td style="padding-bottom:0;padding-top:5px">{{$education['degree'] ?? ""}}{{$education['endYear'] ? ', '.$education['endYear'] : ""}}</td>
                            </tr>
                  			<tr>
                              <td style="padding-top:10px"><p class="details">{!!str_replace("\n","<br/>",$education['details'] ?? "")!!}</p></td>
                  			</tr>
                        @endforeach
                    @endisset
                </tbody>
            </table>
        @endif

        @isset($cv->customSections)
            @foreach ($cv->customSections as $section)
            <table >
                <thead>
                    <tr>
                        <th scope="col" class="section-title" style="padding-bottom:20px;padding-top:20px">{{$section['customSectionTitle'] ?? ""}}</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="padding-top:0">
                            <p>{!!str_replace("\n","<br/>",$section['customSectionDetails'] ?? "")!!}</p>
                        </td>
                    </tr>
                </tbody>
            </table>
            @endforeach
        @endisset
    </div>
    @if($currentLocale == 'ar')
    <div class="page" style="position: relative; float:right; width:66%; background:#fff;height:100%;"></div>
    @else
    <div class="page" style="position: relative; float:left; width:66%; background:#fff;height:100%;"></div>
    @endif
</body>

</html>
