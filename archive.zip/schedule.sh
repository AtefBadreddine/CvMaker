#!/bin/bash
/usr/bin/php /home/u876071247/domains/getyourresume.net/public_html/artisan schedule:run >> /dev/null 2>&1