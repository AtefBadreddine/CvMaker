@php
    $currentLocale = session()->get('selectedLang') ?? ($cv->selectedLang ?? 'en');
@endphp
<!DOCTYPE html>
<html lang="{{ $currentLocale }}" dir="{{ $currentLocale == 'ar' ? 'rtl' : 'ltr' }}">

<head>
    <title>{!! $cv->name ?? '' . "'s cv" !!}</title>

    <!-- Meta -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        *
        {
            font-family:'Cairo'
        }
        body
        {
            margin: 0;
            padding: 0;
            background-color: {{$cv->cv_color ?? '#2e5395'}};
            color: #545E6C;
        }

        table {
            border-spacing: 1;
            border-collapse: collapse;
            overflow: wrap;
            width: 100%;
            margin: 0 auto;
            position: relative;
            padding-top: 15px;
        }

        table * {
            position: relative;
        }


        td,th {
            padding: 20px;
        }

        table td,
        table th {
            font-size: {{$cv->cv_text_size ?? '14'}}px;
            @if($currentLocale == 'ar')
            text-align: right;
            font-family:'Cairo';
            @else
            text-align: left;
            font-family:'Roboto';
            @endif
        }

        .name {
            font-size: {{$cv->cv_text_size+28 ?? '40'}}px;
            color: {{$cv->cv_color ?? '#2e5395'}};
            font-weight: bold;
        }

        table th.title {
            padding-top: 20px;
            font-size: {{$cv->cv_text_size+4 ?? '18'}}px;
            font-weight: 400;
            text-transform: uppercase
        }

        table th.section-title {
            color: {{$cv->cv_color ?? '#2e5395'}};
            font-weight: bold;
            padding-bottom: 0;
            padding-top: 20px;
            font-size: {{$cv->cv_text_size+9 ?? '23'}}px;
            text-transform: uppercase
        }

        .sidebar td,
        .sidebar th
        {
            color:white;
            padding:10px;
            @if($currentLocale == 'ar')
            padding-right: 20px;
            padding-left: 20px;
            @else
            padding-left: 20px;
            padding-right: 20px;
            @endif
        }

        table.personal-info-table th
        {
            padding-bottom: 2px;
        }

        table.personal-info-table td
        {
            padding-top: 2px
        }

        strong.title
        {
            line-height: 25px
        }

    </style>
</head>

<body>
    <div 
        class="sidebar" 
        @if($currentLocale == 'ar')
        style="position: relative;float:right;width: 28%;background:{{$cv->cv_color ?? '#2e5395'}};color:white;"
        @else
        style="position: relative;float:left;width: 28%;background:{{$cv->cv_color ?? '#2e5395'}};color:white;"
        @endif
        >
        <table class="personal-info-table">
            <tbody>
                @if (gettype($cv->picture) === 'string')
                    <tr>
                        <td style="text-align: center; padding-top:30px">
                            <img class="profile mb-2" src="{{ asset('storage/cv/pictures') . '/' . $cv->picture }}" />
                        </td>
                    </tr>
                @endif
                @if ($cv->email)
                    <tr>
                        <th>{{ __('labels.email') }}</th>
                    </tr>
                    <tr>
                        <td>{{ $cv->email }}</td>
                    </tr>
                @endif
                @if ($cv->phone)
                    <tr>
                        <th>{{ __('labels.phone') }}</th>
                    </tr>
                    <tr>
                        <td>{{ $cv->phone }}</td>
                    </tr>
                @endif
                @if ($cv->address)
                    <tr>
                        <th>{{ __('labels.address') }}</th>
                    </tr>
                    <tr>
                        <td>{{ $cv->address }}</td>
                    </tr>
                @endif
                @if ($cv->city)
                    <tr>
                        <th>{{ __('labels.city') }}</th>
                    </tr>
                    <tr>
                        <td>{{ $cv->city }}</td>
                    </tr>
                @endif
                @if ($cv->birth_date)
                    <tr>
                        <th>{{ __('labels.birth_date') }}</th>
                    </tr>
                    <tr>
                        <td>{{ $cv->birth_date }}</td>
                    </tr>
                @endif
                @if ($cv->marital_status)
                    <tr>
                        <th>{{ __('labels.marital_status') }}</th>
                    </tr>
                    <tr>
                        <td>{{ $cv->marital_status }}</td>
                    </tr>
                @endif
                @if ($cv->nationality)
                    <tr>
                        <th>{{ __('labels.nationality') }}</th>
                    </tr>
                    <tr>
                        <td>{{ $cv->nationality }}</td>
                    </tr>
                @endif
            </tbody>
        </table>
        @if ($cv->language || isset($cv->languages))
            <table >
                <thead>
                    <tr>
                        <th colspan="2" class="title">{{ $cv->langs_section_title ?? __('pdf-sections.languages') }}</th>
                    </tr>
                </thead>
                <tbody>
                  @isset($cv->language)
                    <tr>
                        <th scope="col" style="font-weight: 300">{{ $cv->language }}</th>
                        <td>{{ $cv->level ?? '' }}</td>
                    </tr>
                  @endisset
                    @isset($cv->languages)
                        @foreach ($cv->languages as $language)
                            <tr>
                                <th style="font-weight: 300">{{ $language['language'] }}</th>
                                <td>{{ $language['level'] ?? '' }}</td>
                            </tr>
                        @endforeach
                    @endisset
                </tbody>
            </table>
        @endif

        @if ($cv->skill || isset($cv->skills))
            <table >
                <thead>
                    <tr>
                        <th class="title">{{ $cv->skills_section_title ?? __('pdf-sections.skills') }}</th>
                    </tr>
                </thead>
                <tbody>
                  	@isset($cv->skill)
                    <tr>
                        <td>{{ $cv->skill }}</td>
                    </tr>
                  	@endisset
                    @isset($cv->skills)
                        @foreach ($cv->skills as $skill)
                            <tr>
                                <td>{{ $skill['skill'] }}</td>
                            </tr>
                        @endforeach
                    @endisset
                </tbody>
            </table>
        @endif

        @isset($cv->interests)
            <table>
                <thead>
                    <tr>
                        <th class="title">{{ $cv->interests_section_title ?? __('pdf-sections.interests') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($cv->interests as $interest)
                        <tr>
                            <td>{{ $interest['interest'] }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>  
        @endisset
    </div>

    <div 
        class="page" 
        @if($currentLocale == 'ar')
        style="position: relative; float:left; width:70%; background:#fff;height:100%;page-break-inside: avoid;"
        @else
        style="position: relative; float:right; width:70%; background:#fff;height:100%;page-break-inside: avoid;"
        @endif
        >
        <table style="border-bottom: 4px double #222; width:95%">
            <tbody>
                <tr>
                    <td>
                        <strong class="name">{{$cv->name ?? ""}}</strong>
                        <br>
                        <strong>{{$cv->current_job ?? ""}}</strong>
                    </td>
                </tr>
            </tbody>
        </table>

        @if($cv->profession_summary)
            <table style="width:95%;">
                <tbody>
                    <tr>
                        <td><p style="text-align: justify">{!!str_replace("\n","<br/>",$cv->profession_summary)!!}</p></td>
                    </tr>
                </tbody>
            </table>
        @endif

        @if($cv->jobs)
            <table style="width:95%;">
                <thead>
                    <tr>
                        <th scope="col" class="section-title">{{$cv->jobs_section_title ?? __('pdf-sections.experiences')}}</th>
                    </tr>
                </thead>
                <tbody>

                    @isset($cv->jobs)
                        @foreach ($cv->jobs as  $job)
                            <tr>
                                <th style="padding-bottom: 5px">{{$job['job_title'] ?? ""}} {{$job['employer'] ? ', '.$job['employer'] : ""}}</th>
                            </tr>
                            <tr>
                                <td scope="col" style="padding-top: 0">
                                    {{$job['job_city'] ? $job['job_city'] . ' , ' : ""}}{{$job['jobStartYear'] ? $job['jobStartYear'] . ' - ' : ""}}{{$job['jobEndYear'] ?? ""}}
                                    <p style="padding-top: 10px">{!!str_replace("\n","<br/>",$job['details'] ?? "")!!}</p>
                                </td>
                            </tr>
                        @endforeach
                    @endisset
                </tbody>
            </table>
        @endif

        @if($cv->educations)
            <table style="width:95%;">
                <thead>
                    <tr>
                        <th scope="col" class="section-title">{{$cv->education_section_title ?? __('pdf-sections.education')}}</th>
                    </tr>
                </thead>
                <tbody>

                    @isset($cv->educations)
                        @foreach ($cv->educations as  $education)
                            <tr>
                                <td scope="col">
                                    <strong class="title">{{$education['degree'] ?? ""}}{{$education['university'] ? ', '.$education['university'] : ""}}</strong>
                                    <br>
                                    {{$education['education_city'] ? $education['education_city'] . ' , ' : ""}}{{$education['startYear'] ? $education['startYear'] . ' - ' : ""}}{{$education['endYear'] ?? ""}}
                                  	<p style="padding-top: 10px">{!!str_replace("\n","<br/>",$education['details'] ?? "")!!}</p>
                                </td>
                            </tr>
                        @endforeach
                    @endisset
                </tbody>
            </table>
        @endif

        @isset($cv->customSections)
            @foreach ($cv->customSections as $section)
            <table style="width:95%;">
                <thead>
                    <tr>
                        <th scope="col" class="section-title">{{$section['customSectionTitle'] ?? ""}}</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <p>{!!str_replace("\n","<br/>",$section['customSectionDetails'] ?? "")!!}</p>
                        </td>
                    </tr>
                </tbody>
            </table>
            @endforeach
        @endisset
    </div>
    @if($currentLocale == 'ar')
    <div class="page" style="position: relative; float:left; width:70%; background:#fff;height:100%;"></div>
    @else
    <div class="page" style="position: relative; float:right; width:70%; background:#fff;height:100%;"></div>
    @endif
</body>

</html>
